﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace AdmissionSystemAPI.Models
{
    public class DbAdmissionSystem:DbContext
    {
        public DbAdmissionSystem(DbContextOptions<DbAdmissionSystem> db) : base(db)
        {

        }
        public DbSet<SchoolInfo> SchoolInfos { get; set; }
        public DbSet<Address> Addresses { get; set; }
        public DbSet<EducationSystem> EducationSystems { get; set; }
        public DbSet<StudentInfo> StudentInfos { get; set; }
        public DbSet<PreviousSchoolInfo> PreviousSchoolInfos { get; set; }
        public DbSet<Token> Tokens { get; set; }
        public DbSet<AdmissionClass> AdmissionClasses { get; set; }
        public DbSet<ApplyForm> ApplyForms { get; set; }
        public DbSet<Payment> Payments { get; set; }
        public DbSet<AdmitCard> AdmitCards { get; set; }
        public DbSet<Result> Results { get; set; }
        public DbSet<Notice> Notices { get; set; }
        public DbSet<StudentSubjectGPA> StudentSubjectGPAs { get; set; }
        public DbSet<ExamInfo> ExamInfos { get; set; }
    }
    public enum group { Science = 1, Humanities, BusinessStudies }
    public enum shift { Morning, Day, Both }
    public class SchoolInfo
    {
        public int Id { get; set; }
        public int EIIN { get; set; }
        public int ParentId { get; set; }
        public string SchoolName { get; set; }
        public string TokenCode { get; set; }
        [ForeignKey("EducationSystem")]
        public int EduSystem { get; set; }
        [ForeignKey("Address")]
        public int AddressInfo { get; set; }
        public DateTime SchoolRegDate { get; set; }
        public string PrincipalSeal { get; set; }
        public string PrincipalSigneture { get; set; }
        public group Group { get; set; }
        public string Email { get; set; }
        public string WebSite { get; set; }
        public shift ShiftName { get; set; }
        public string ContactNumber1 { get; set; }
        public string ContactNumber2 { get; set; }
        public string Logo { get; set; }

        public virtual EducationSystem EducationSystem { get; set; }
        public virtual Address Address { get; set; }


        public virtual ICollection<Token> Tokens { get; set; }
        public virtual ICollection<AdmissionClass> AdmissionClasses { get; set; }
        public virtual ICollection<ApplyForm> ApplyForms { get; set; }
        public virtual ICollection<Notice> Notices { get; set; }
    }
    public class Address
    {
        public int Id { get; set; }
        public string HouseNo { get; set; }
        public string RoadNo { get; set; }
        public string WordNo { get; set; }
        public string UnionOrCityCorporation { get; set; }
        public string ZipCode { get; set; }
        public string District { get; set; }

        public virtual ICollection<SchoolInfo> SchoolInfos { get; set; }
        public virtual ICollection<StudentInfo> StudentInfos { get; set; }

    }
    public class EducationSystem
    {
        public int Id { get; set; }
        public string Type { get; set; }

        public virtual ICollection<SchoolInfo> SchoolInfos { get; set; }
    }
    public class StudentInfo
    {
        public int Id { get; set; }
        public string StudentName { get; set; }
        public DateTime DOB { get; set; }
        public int BirthCertificateID { get; set; }
        public string Gender { get; set; }
        public string Religion { get; set; }
        public string Height { get; set; }
        public string BloodGroup { get; set; }
        public string FatherName { get; set; }
        public string FatherOccupation { get; set; }
        public string FatherPhone { get; set; }
        public string MotherName { get; set; }
        public string MotherOccupation { get; set; }
        public string MotherPhone { get; set; }
        public string GardianName { get; set; }
        public string GardianOccupation { get; set; }
        public string GardianPhone { get; set; }
        [ForeignKey("PreviousSchoolInfo")]
        public int PreviousSchoolInfoId { get; set; }
        public string Email { get; set; }
        [ForeignKey("Address")]
        public int StudentAddress { get; set; }
        public string ContuctNumber { get; set; }
        public string Photo { get; set; }
        public string Signature { get; set; }
        public DateTime StudentRegDate { get; set; }

        public virtual Address Address { get; set; }
        public virtual PreviousSchoolInfo PreviousSchoolInfo { get; set; }

        public virtual ICollection<Token> Tokens { get; set; }
        public virtual ICollection<ApplyForm> ApplyForms { get; set; }


    }
    public class PreviousSchoolInfo
    {
        public int Id { get; set; }
        public string PreviousExam { get; set; }
        public string Board { get; set; }
        public string PreviousSchool { get; set; }
        public int Roll { get; set; }
        public int RegistrationNumber { get; set; }
        public int PassingYear { get; set; }
        public Decimal ResultGPA { get; set; }


        public virtual ICollection<StudentInfo> StudentInfos { get; set; }
    }    
    public class Token
    {
        public int Id { get; set; }
        [ForeignKey("SchoolInfo")]
        public int SchoolId { get; set; }
        public string TokenNum { get; set; }
        [ForeignKey("StudentInfo")]
        public int StudentId { get; set; }

        public virtual SchoolInfo SchoolInfo { get; set; }
        public virtual StudentInfo StudentInfo { get; set; }

        public virtual ICollection<ApplyForm> ApplyForms { get; set; }
        public virtual ICollection<Result> Results { get; set; }
        public virtual ICollection<ExamInfo> ExamInfos { get; set; }

    }
    public class AdmissionClass
    {
        public int Id { get; set; }
        [ForeignKey("SchoolInfo")]
        public int SchoolId { get; set; }
        public shift ShiftName { get; set; }
        public string Class { get; set; }
        public int NumberOfSeat { get; set; }

        public virtual SchoolInfo SchoolInfo { get; set; }

        public virtual ICollection<ApplyForm> ApplyForms { get; set; }
        public virtual ICollection<Notice> Notices { get; set; }
    }
    public class ApplyForm
    {
        public int Id { get; set; }
        [ForeignKey("SchoolInfo")]
        public int SchoolId { get; set; }
        [ForeignKey("AdmissionClass")]
        public int AdmissionClas { get; set; }
        [ForeignKey("StudentInfo")]
        public int StudentId { get; set; }
        [ForeignKey("Token")]
        public int TokenId { get; set; }
        [ForeignKey("StudentSubjectGPA")]
        public int SubjectWiseGPAs { get; set; }
        public shift Shift { get; set; }
        public group Group { get; set; }
        public DateTime ApplyDate { get; set; }
        public bool PaymentStatus { get; set; }

        //public decimal ResultGPA { get; set; }
        //public decimal Sub1GPA { get; set; }
        //public decimal Sub2GPA { get; set; }
        //public decimal Sub3GPA { get; set; }
        //public decimal Sub4GPA { get; set; }

        public virtual SchoolInfo SchoolInfo { get; set; }
        public virtual AdmissionClass AdmissionClass { get; set; }
        public virtual StudentInfo StudentInfo { get; set; }
        public virtual Token Token { get; set; }
        public virtual StudentSubjectGPA StudentSubjectGPA { get; set; }

        public virtual ICollection<Payment> Payments { get; set; }
        public virtual ICollection<AdmitCard> AdmitCards { get; set; }

    }
    public class Payment
    {
        public int Id { get; set; }
        public string Method { get; set; }
        [ForeignKey("ApplyForm")]
        public int ApplyID { get; set; }
        public string TrxID { get; set; }


        public virtual ApplyForm ApplyForm { get; set; }
    }
    public class AdmitCard
    {
        public int Id { get; set; }
        [ForeignKey("ApplyForm")]
        public int ApplicationID { get; set; }
        public DateTime IssueDate { get; set; }
        public DateTime ResultDate { get; set; }

        public virtual ApplyForm ApplyForm { get; set; }

    }
    public class Result
    {
        public int Id { get; set; }
        [ForeignKey("Token")]
        public int TokenNumber { get; set; }
        [ForeignKey("ExamInfo")]
        public int ExamInfoId { get; set; }
        public decimal TotalScore { get; set; }
        public bool IsSelected { get; set; }
        public string Merit { get; set; }
        public string Class { get; set; }
        public shift Shift { get; set; }
        public string Year { get; set; }

        public virtual Token Token { get; set; }
        public virtual ExamInfo ExamInfo { get; set; }


    }
    public class Notice
    {
        public int Id { get; set; }
        public string Tittle { get; set; }
        public string NoticeId { get; set; }
        [ForeignKey("SchoolInfo")]
        public int SchoolId { get; set; }
        [ForeignKey("AdmissionClass")]
        public int AdmissionClas { get; set; }
        public shift Shift { get; set; }
        public int AvailableSeat { get; set; }
        public DateTime StartApplyDate { get; set; }
        public DateTime LastApplyDate { get; set; }
        public DateTime NoticeDate { get; set; }
        public DateTime AdmissionDate { get; set; }
        public DateTime ExamDateOrLotteryDate { get; set; }

        public virtual SchoolInfo SchoolInfo { get; set; }
        public virtual AdmissionClass AdmissionClass { get; set; }

    }
    public enum subjects {Bangla=1,English,Mathmetics }
    public class StudentSubjectGPA
    {
        public int Id { get; set; }
        public subjects Name { get; set; }
        public decimal GPA { get; set; }

        public virtual ApplyForm ApplyForm { get; set; }
    }
    public class ExamInfo
    {
        public int Id { get; set; }
        [ForeignKey("Notice")]
        public int NoticeId { get; set; }
        public DateTime ExamDate { get; set; }
        [ForeignKey("Token")]
        public int TokenId { get; set; }
        public decimal TotalMarks { get; set; }
        public decimal ObtainedMark { get; set; }
        public decimal PassMark { get; set; }

        public virtual Notice Notice { get; set; }
        public virtual Token Token { get; set; }

        public virtual ICollection<Result> Results { get; set; }
    }  
    
}
