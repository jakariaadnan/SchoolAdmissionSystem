﻿using AdmissionSystemAPI.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace AdmissionSystemAPI.ViewModels
{
    public class ApplyVM
    {
        public int Id { get; set; }
        public int SchoolId { get; set; }
        public int AdmissionClas { get; set; }
        public int StudentId { get; set; }
        public string TokenId { get; set; }
        public int SubjectWiseGPAs { get; set; }
        public shift Shift { get; set; }
        public group Group { get; set; }
        public DateTime ApplyDate { get; set; }
        public bool PaymentStatus { get; set; }
        public string StudentName { get; set; }
        public DateTime DOB { get; set; }
        public int BirthCertificateID { get; set; }
        public string Gender { get; set; }
        public string Religion { get; set; }
        public string Height { get; set; }
        public string BloodGroup { get; set; }
        public string FatherName { get; set; }
        public string FatherOccupation { get; set; }
        public string FatherPhone { get; set; }
        public string MotherName { get; set; }
        public string MotherOccupation { get; set; }
        public string MotherPhone { get; set; }
        public string GardianName { get; set; }
        public string GardianOccupation { get; set; }
        public string GardianPhone { get; set; }
        public int PreviousSchoolInfoId { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public int StudentAddress { get; set; }
        public string ContuctNumber { get; set; }
        public string Photo { get; set; }
        public string Signature { get; set; }
        public DateTime StudentRegDate { get; set; }
        public bool IsEdit { get; set; }
    }
}
