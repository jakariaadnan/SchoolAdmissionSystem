﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using AdmissionSystemAPI.Models;
using AdmissionSystemAPI.ViewModels;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Options;
using System.Security.Cryptography;

namespace AdmissionSystemAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ApplyFormsController : ControllerBase
    {
        private readonly DbAdmissionSystem _context;
        private readonly UserManager<User> _userManager;
        private readonly RoleManager<Role> _roleManager;
        private readonly JwtSettings _jwtSettings;

        public ApplyFormsController(DbAdmissionSystem context, UserManager<User> u, RoleManager<Role> r, IOptionsSnapshot<JwtSettings> jwtSettings)
        {
            _context = context;
            this._userManager = u;
            this._roleManager = r;
            _jwtSettings = jwtSettings.Value;
        }

        // GET: api/ApplyForms
        [HttpGet]
        public async Task<ActionResult<IEnumerable<ApplyForm>>> GetApplyForms()
        {
            return await _context.ApplyForms.ToListAsync();
        }

        // GET: api/ApplyForms/5
        [HttpGet("{id}")]
        public async Task<ActionResult<ApplyForm>> GetApplyForm(int id)
        {
            var applyForm = await _context.ApplyForms.FindAsync(id);

            if (applyForm == null)
            {
                return NotFound();
            }

            return applyForm;
        }

        // PUT: api/ApplyForms/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{id}")]
        //public async Task<IActionResult> PutApplyForm(int id, ApplyForm applyForm)
        //{
        //    if (id != applyForm.Id)
        //    {
        //        return BadRequest();
        //    }

        //    _context.Entry(applyForm).State = EntityState.Modified;

        //    try
        //    {
        //        await _context.SaveChangesAsync();
        //    }
        //    catch (DbUpdateConcurrencyException)
        //    {
        //        if (!ApplyFormExists(id))
        //        {
        //            return NotFound();
        //        }
        //        else
        //        {
        //            throw;
        //        }
        //    }

        //    return NoContent();
        //}

        public async Task<IActionResult> PutApplyForm(int id, ApplyVM applyVM)
        {
            if (applyVM.IsEdit == true)
            {
                var applyForm = new ApplyForm
                {
                    Id = applyVM.Id,
                    SchoolId = applyVM.SchoolId,
                    StudentId=applyVM.StudentId,
                    AdmissionClas = applyVM.AdmissionClas,
                    TokenId = applyVM.TokenId,
                    SubjectWiseGPAs = applyVM.SubjectWiseGPAs,
                    Shift = applyVM.Shift,
                    Group = applyVM.Group,
                    ApplyDate = DateTime.Now,
                    IsEdit = false
                };
                    using (var transection = _context.Database.BeginTransaction())
                    {
                        try
                        {
                            var sInfo = new StudentInfo();
                            sInfo.Id = applyVM.StudentId;
                            sInfo.StudentName = applyVM.StudentName;
                            sInfo.DOB = applyVM.DOB;
                            sInfo.BirthCertificateID = applyVM.BirthCertificateID;
                            sInfo.Gender = applyVM.Gender;
                            sInfo.Religion = applyVM.Religion;
                            sInfo.Height = applyVM.Height;
                            sInfo.BloodGroup = applyVM.BloodGroup;
                            sInfo.FatherName = applyVM.FatherName;
                            sInfo.FatherOccupation = applyVM.FatherOccupation;
                            sInfo.FatherPhone = applyVM.FatherPhone;
                            sInfo.MotherName = applyVM.MotherName;
                            sInfo.MotherOccupation = applyVM.MotherOccupation;
                            sInfo.MotherPhone = applyVM.MotherPhone;
                            sInfo.GardianName = applyVM.GardianName;
                            sInfo.GardianOccupation = applyVM.GardianOccupation;
                            sInfo.GardianPhone = applyVM.GardianPhone;
                            sInfo.PreviousSchoolInfoId = applyVM.PreviousSchoolInfoId;
                            sInfo.Email = applyVM.Email;
                            sInfo.StudentAddress = applyVM.StudentAddress;
                            sInfo.ContuctNumber = applyVM.ContuctNumber;
                            sInfo.Photo = applyVM.Photo;
                            sInfo.Signature = applyVM.Signature;
                            sInfo.StudentRegDate = DateTime.Now;

                            _context.Entry(sInfo).State = EntityState.Modified;
                            await _context.SaveChangesAsync(); 
                            _context.Entry(applyForm).State = EntityState.Modified;
                            await _context.SaveChangesAsync();
                            transection.Commit();

                        }
                        catch (Exception e)
                        {

                            transection.Rollback();
                            throw e;
                        }
                    

                    }
                
            }
            else
            {
                return Content("You are not approved to edit apply form");
            }

            return CreatedAtAction("GetApplyForm", new { id = applyVM.Id }, applyVM);
        }

        // POST: api/ApplyForms
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost]
        public async Task<ActionResult<ApplyForm>> PostApplyForm(ApplyVM applyFormVM)
        {
            var random = new Random();
            var applyForm = new ApplyForm
            {
                SchoolId = applyFormVM.SchoolId,
                AdmissionClas = applyFormVM.AdmissionClas,
                StudentId = applyFormVM.StudentId,
                
                TokenId = random.Next(100000,999999).ToString(),
                SubjectWiseGPAs = applyFormVM.SubjectWiseGPAs,
                Shift = applyFormVM.Shift,
                Group = applyFormVM.Group,
                ApplyDate = DateTime.Now,
                IsEdit=false
            };
            if (applyForm.StudentId == 0)
            {
                using (var transection = _context.Database.BeginTransaction())
                {
                    try
                    {
                        var sInfo = new StudentInfo();
                        sInfo.StudentName = applyFormVM.StudentName;
                        sInfo.DOB = applyFormVM.DOB;
                        sInfo.BirthCertificateID = applyFormVM.BirthCertificateID;
                        sInfo.Gender = applyFormVM.Gender;
                        sInfo.Religion = applyFormVM.Religion;
                        sInfo.Height = applyFormVM.Height;
                        sInfo.BloodGroup = applyFormVM.BloodGroup;
                        sInfo.FatherName = applyFormVM.FatherName;
                        sInfo.FatherOccupation = applyFormVM.FatherOccupation;
                        sInfo.FatherPhone = applyFormVM.FatherPhone;
                        sInfo.MotherName = applyFormVM.MotherName;
                        sInfo.MotherOccupation = applyFormVM.MotherOccupation;
                        sInfo.MotherPhone = applyFormVM.MotherPhone;
                        sInfo.GardianName = applyFormVM.GardianName;
                        sInfo.GardianOccupation = applyFormVM.GardianOccupation;
                        sInfo.GardianPhone = applyFormVM.GardianPhone;
                        sInfo.PreviousSchoolInfoId = applyFormVM.PreviousSchoolInfoId;
                        sInfo.Email = applyFormVM.Email;
                        sInfo.StudentAddress = applyFormVM.StudentAddress;
                        sInfo.ContuctNumber = applyFormVM.ContuctNumber;
                        sInfo.Photo = applyFormVM.Photo;
                        sInfo.Signature = applyFormVM.Signature;
                        sInfo.StudentRegDate = DateTime.Now;

                        var user = new User
                        {
                            UserName = applyFormVM.StudentName,
                            Email = applyFormVM.Email
                        };
                        var result = await _userManager.CreateAsync(user, applyFormVM.Password);
                        if (result.Succeeded)
                        {
                            var userAss = _userManager.Users.SingleOrDefault(u => u.Email == applyFormVM.Email);
                            var r= await _userManager.AddToRoleAsync(user, "Students");
                        }
                        
                        await _context.StudentInfos.AddAsync(sInfo);                        
                        await _context.SaveChangesAsync();
                        var id = _context.StudentInfos.Max(p=>p.Id);
                        applyForm.StudentId = id;
                        applyForm.PaymentStatus = false;
                        await _context.ApplyForms.AddAsync(applyForm);
                        await _context.SaveChangesAsync();
                        transection.Commit();
                    
                    }
                    catch (Exception e)
                    {

                        transection.Rollback();
                        throw e;
                    }
                }
            }
            else
            {
                applyForm.PaymentStatus = false;
                await _context.ApplyForms.AddAsync(applyForm);
                await _context.SaveChangesAsync();
            }
            return CreatedAtAction("GetApplyForm", new { id = applyFormVM.Id }, applyFormVM);
        }

        // DELETE: api/ApplyForms/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<ApplyForm>> DeleteApplyForm(int id)
        {
            var applyForm = await _context.ApplyForms.FindAsync(id);
            if (applyForm == null)
            {
                return NotFound();
            }

            _context.ApplyForms.Remove(applyForm);
            await _context.SaveChangesAsync();

            return applyForm;
        }

        private bool ApplyFormExists(int id)
        {
            return _context.ApplyForms.Any(e => e.Id == id);
        }
    }
}
