﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace AdmissionSystemAPI.Migrations
{
    public partial class applyIsEdit : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "IsEdit",
                table: "ApplyForms",
                nullable: false,
                defaultValue: false);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "IsEdit",
                table: "ApplyForms");
        }
    }
}
