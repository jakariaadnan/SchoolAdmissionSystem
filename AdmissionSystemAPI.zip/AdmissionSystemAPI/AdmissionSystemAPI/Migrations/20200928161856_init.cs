﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace AdmissionSystemAPI.Migrations
{
    public partial class init : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Addresses",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    HouseNo = table.Column<string>(nullable: true),
                    RoadNo = table.Column<string>(nullable: true),
                    WordNo = table.Column<string>(nullable: true),
                    UnionOrCityCorporation = table.Column<string>(nullable: true),
                    ZipCode = table.Column<string>(nullable: true),
                    District = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Addresses", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "AspNetRoles",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Name = table.Column<string>(maxLength: 256, nullable: true),
                    NormalizedName = table.Column<string>(maxLength: 256, nullable: true),
                    ConcurrencyStamp = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetRoles", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUsers",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    UserName = table.Column<string>(maxLength: 256, nullable: true),
                    NormalizedUserName = table.Column<string>(maxLength: 256, nullable: true),
                    Email = table.Column<string>(maxLength: 256, nullable: true),
                    NormalizedEmail = table.Column<string>(maxLength: 256, nullable: true),
                    EmailConfirmed = table.Column<bool>(nullable: false),
                    PasswordHash = table.Column<string>(nullable: true),
                    SecurityStamp = table.Column<string>(nullable: true),
                    ConcurrencyStamp = table.Column<string>(nullable: true),
                    PhoneNumber = table.Column<string>(nullable: true),
                    PhoneNumberConfirmed = table.Column<bool>(nullable: false),
                    TwoFactorEnabled = table.Column<bool>(nullable: false),
                    LockoutEnd = table.Column<DateTimeOffset>(nullable: true),
                    LockoutEnabled = table.Column<bool>(nullable: false),
                    AccessFailedCount = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUsers", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "EducationSystems",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Type = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EducationSystems", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "PreviousSchoolInfos",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PreviousExam = table.Column<string>(nullable: true),
                    Board = table.Column<string>(nullable: true),
                    PreviousSchool = table.Column<string>(nullable: true),
                    Roll = table.Column<int>(nullable: false),
                    RegistrationNumber = table.Column<int>(nullable: false),
                    PassingYear = table.Column<int>(nullable: false),
                    ResultGPA = table.Column<decimal>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PreviousSchoolInfos", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "StudentSubjectGPAs",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<int>(nullable: false),
                    GPA = table.Column<decimal>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_StudentSubjectGPAs", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "AspNetRoleClaims",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    RoleId = table.Column<Guid>(nullable: false),
                    ClaimType = table.Column<string>(nullable: true),
                    ClaimValue = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetRoleClaims", x => x.Id);
                    table.ForeignKey(
                        name: "FK_AspNetRoleClaims_AspNetRoles_RoleId",
                        column: x => x.RoleId,
                        principalTable: "AspNetRoles",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUserClaims",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserId = table.Column<Guid>(nullable: false),
                    ClaimType = table.Column<string>(nullable: true),
                    ClaimValue = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUserClaims", x => x.Id);
                    table.ForeignKey(
                        name: "FK_AspNetUserClaims_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUserLogins",
                columns: table => new
                {
                    LoginProvider = table.Column<string>(nullable: false),
                    ProviderKey = table.Column<string>(nullable: false),
                    ProviderDisplayName = table.Column<string>(nullable: true),
                    UserId = table.Column<Guid>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUserLogins", x => new { x.LoginProvider, x.ProviderKey });
                    table.ForeignKey(
                        name: "FK_AspNetUserLogins_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUserRoles",
                columns: table => new
                {
                    UserId = table.Column<Guid>(nullable: false),
                    RoleId = table.Column<Guid>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUserRoles", x => new { x.UserId, x.RoleId });
                    table.ForeignKey(
                        name: "FK_AspNetUserRoles_AspNetRoles_RoleId",
                        column: x => x.RoleId,
                        principalTable: "AspNetRoles",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_AspNetUserRoles_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUserTokens",
                columns: table => new
                {
                    UserId = table.Column<Guid>(nullable: false),
                    LoginProvider = table.Column<string>(nullable: false),
                    Name = table.Column<string>(nullable: false),
                    Value = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUserTokens", x => new { x.UserId, x.LoginProvider, x.Name });
                    table.ForeignKey(
                        name: "FK_AspNetUserTokens_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "SchoolInfos",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    EIIN = table.Column<int>(nullable: false),
                    ParentId = table.Column<int>(nullable: false),
                    SchoolName = table.Column<string>(nullable: true),
                    TokenCode = table.Column<string>(nullable: true),
                    EduSystem = table.Column<int>(nullable: false),
                    AddressInfo = table.Column<int>(nullable: false),
                    SchoolRegDate = table.Column<DateTime>(nullable: false),
                    PrincipalSeal = table.Column<string>(nullable: true),
                    PrincipalSigneture = table.Column<string>(nullable: true),
                    Group = table.Column<int>(nullable: false),
                    Email = table.Column<string>(nullable: true),
                    WebSite = table.Column<string>(nullable: true),
                    ShiftName = table.Column<int>(nullable: false),
                    ContactNumber1 = table.Column<string>(nullable: true),
                    ContactNumber2 = table.Column<string>(nullable: true),
                    Logo = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SchoolInfos", x => x.Id);
                    table.ForeignKey(
                        name: "FK_SchoolInfos_Addresses_AddressInfo",
                        column: x => x.AddressInfo,
                        principalTable: "Addresses",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_SchoolInfos_EducationSystems_EduSystem",
                        column: x => x.EduSystem,
                        principalTable: "EducationSystems",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "StudentInfos",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    StudentName = table.Column<string>(nullable: true),
                    DOB = table.Column<DateTime>(nullable: false),
                    BirthCertificateID = table.Column<int>(nullable: false),
                    Gender = table.Column<string>(nullable: true),
                    Religion = table.Column<string>(nullable: true),
                    Height = table.Column<string>(nullable: true),
                    BloodGroup = table.Column<string>(nullable: true),
                    FatherName = table.Column<string>(nullable: true),
                    FatherOccupation = table.Column<string>(nullable: true),
                    FatherPhone = table.Column<string>(nullable: true),
                    MotherName = table.Column<string>(nullable: true),
                    MotherOccupation = table.Column<string>(nullable: true),
                    MotherPhone = table.Column<string>(nullable: true),
                    GardianName = table.Column<string>(nullable: true),
                    GardianOccupation = table.Column<string>(nullable: true),
                    GardianPhone = table.Column<string>(nullable: true),
                    PreviousSchoolInfoId = table.Column<int>(nullable: false),
                    Email = table.Column<string>(nullable: true),
                    StudentAddress = table.Column<int>(nullable: false),
                    ContuctNumber = table.Column<string>(nullable: true),
                    Photo = table.Column<string>(nullable: true),
                    Signature = table.Column<string>(nullable: true),
                    StudentRegDate = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_StudentInfos", x => x.Id);
                    table.ForeignKey(
                        name: "FK_StudentInfos_PreviousSchoolInfos_PreviousSchoolInfoId",
                        column: x => x.PreviousSchoolInfoId,
                        principalTable: "PreviousSchoolInfos",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_StudentInfos_Addresses_StudentAddress",
                        column: x => x.StudentAddress,
                        principalTable: "Addresses",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "AdmissionClasses",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    SchoolId = table.Column<int>(nullable: false),
                    ShiftName = table.Column<int>(nullable: false),
                    Class = table.Column<string>(nullable: true),
                    NumberOfSeat = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AdmissionClasses", x => x.Id);
                    table.ForeignKey(
                        name: "FK_AdmissionClasses_SchoolInfos_SchoolId",
                        column: x => x.SchoolId,
                        principalTable: "SchoolInfos",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Tokens",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    SchoolId = table.Column<int>(nullable: false),
                    TokenNum = table.Column<string>(nullable: true),
                    StudentId = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tokens", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Tokens_SchoolInfos_SchoolId",
                        column: x => x.SchoolId,
                        principalTable: "SchoolInfos",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.NoAction);
                    table.ForeignKey(
                        name: "FK_Tokens_StudentInfos_StudentId",
                        column: x => x.StudentId,
                        principalTable: "StudentInfos",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.NoAction);
                });

            migrationBuilder.CreateTable(
                name: "Notices",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Tittle = table.Column<string>(nullable: true),
                    NoticeId = table.Column<string>(nullable: true),
                    SchoolId = table.Column<int>(nullable: false),
                    AdmissionClas = table.Column<int>(nullable: false),
                    Shift = table.Column<int>(nullable: false),
                    AvailableSeat = table.Column<int>(nullable: false),
                    StartApplyDate = table.Column<DateTime>(nullable: false),
                    LastApplyDate = table.Column<DateTime>(nullable: false),
                    NoticeDate = table.Column<DateTime>(nullable: false),
                    AdmissionDate = table.Column<DateTime>(nullable: false),
                    ExamDateOrLotteryDate = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Notices", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Notices_AdmissionClasses_AdmissionClas",
                        column: x => x.AdmissionClas,
                        principalTable: "AdmissionClasses",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.NoAction);
                    table.ForeignKey(
                        name: "FK_Notices_SchoolInfos_SchoolId",
                        column: x => x.SchoolId,
                        principalTable: "SchoolInfos",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.NoAction);
                });

            migrationBuilder.CreateTable(
                name: "ApplyForms",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    SchoolId = table.Column<int>(nullable: false),
                    AdmissionClas = table.Column<int>(nullable: false),
                    StudentId = table.Column<int>(nullable: false),
                    TokenId = table.Column<int>(nullable: false),
                    SubjectWiseGPAs = table.Column<int>(nullable: false),
                    Shift = table.Column<int>(nullable: false),
                    Group = table.Column<int>(nullable: false),
                    ApplyDate = table.Column<DateTime>(nullable: false),
                    PaymentStatus = table.Column<bool>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ApplyForms", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ApplyForms_AdmissionClasses_AdmissionClas",
                        column: x => x.AdmissionClas,
                        principalTable: "AdmissionClasses",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.NoAction);
                    table.ForeignKey(
                        name: "FK_ApplyForms_SchoolInfos_SchoolId",
                        column: x => x.SchoolId,
                        principalTable: "SchoolInfos",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.NoAction);
                    table.ForeignKey(
                        name: "FK_ApplyForms_StudentInfos_StudentId",
                        column: x => x.StudentId,
                        principalTable: "StudentInfos",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.NoAction);
                    table.ForeignKey(
                        name: "FK_ApplyForms_StudentSubjectGPAs_SubjectWiseGPAs",
                        column: x => x.SubjectWiseGPAs,
                        principalTable: "StudentSubjectGPAs",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.NoAction);
                    table.ForeignKey(
                        name: "FK_ApplyForms_Tokens_TokenId",
                        column: x => x.TokenId,
                        principalTable: "Tokens",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.NoAction);
                });

            migrationBuilder.CreateTable(
                name: "ExamInfos",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    NoticeId = table.Column<int>(nullable: false),
                    ExamDate = table.Column<DateTime>(nullable: false),
                    TokenId = table.Column<int>(nullable: false),
                    TotalMarks = table.Column<decimal>(nullable: false),
                    ObtainedMark = table.Column<decimal>(nullable: false),
                    PassMark = table.Column<decimal>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ExamInfos", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ExamInfos_Notices_NoticeId",
                        column: x => x.NoticeId,
                        principalTable: "Notices",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ExamInfos_Tokens_TokenId",
                        column: x => x.TokenId,
                        principalTable: "Tokens",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "AdmitCards",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ApplicationID = table.Column<int>(nullable: false),
                    IssueDate = table.Column<DateTime>(nullable: false),
                    ResultDate = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AdmitCards", x => x.Id);
                    table.ForeignKey(
                        name: "FK_AdmitCards_ApplyForms_ApplicationID",
                        column: x => x.ApplicationID,
                        principalTable: "ApplyForms",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Payments",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Method = table.Column<string>(nullable: true),
                    ApplyID = table.Column<int>(nullable: false),
                    TrxID = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Payments", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Payments_ApplyForms_ApplyID",
                        column: x => x.ApplyID,
                        principalTable: "ApplyForms",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Results",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TokenNumber = table.Column<int>(nullable: false),
                    ExamInfoId = table.Column<int>(nullable: false),
                    TotalScore = table.Column<decimal>(nullable: false),
                    IsSelected = table.Column<bool>(nullable: false),
                    Merit = table.Column<string>(nullable: false),
                    Class = table.Column<string>(nullable: false),
                    Shift = table.Column<int>(nullable: false),
                    Year = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Results", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Results_ExamInfos_ExamInfoId",
                        column: x => x.ExamInfoId,
                        principalTable: "ExamInfos",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.NoAction);
                    table.ForeignKey(
                        name: "FK_Results_Tokens_TokenNumber",
                        column: x => x.TokenNumber,
                        principalTable: "Tokens",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.NoAction);
                });

            migrationBuilder.CreateIndex(
                name: "IX_AdmissionClasses_SchoolId",
                table: "AdmissionClasses",
                column: "SchoolId");

            migrationBuilder.CreateIndex(
                name: "IX_AdmitCards_ApplicationID",
                table: "AdmitCards",
                column: "ApplicationID");

            migrationBuilder.CreateIndex(
                name: "IX_ApplyForms_AdmissionClas",
                table: "ApplyForms",
                column: "AdmissionClas");

            migrationBuilder.CreateIndex(
                name: "IX_ApplyForms_SchoolId",
                table: "ApplyForms",
                column: "SchoolId");

            migrationBuilder.CreateIndex(
                name: "IX_ApplyForms_StudentId",
                table: "ApplyForms",
                column: "StudentId");

            migrationBuilder.CreateIndex(
                name: "IX_ApplyForms_SubjectWiseGPAs",
                table: "ApplyForms",
                column: "SubjectWiseGPAs",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_ApplyForms_TokenId",
                table: "ApplyForms",
                column: "TokenId");

            migrationBuilder.CreateIndex(
                name: "IX_AspNetRoleClaims_RoleId",
                table: "AspNetRoleClaims",
                column: "RoleId");

            migrationBuilder.CreateIndex(
                name: "RoleNameIndex",
                table: "AspNetRoles",
                column: "NormalizedName",
                unique: true,
                filter: "[NormalizedName] IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUserClaims_UserId",
                table: "AspNetUserClaims",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUserLogins_UserId",
                table: "AspNetUserLogins",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUserRoles_RoleId",
                table: "AspNetUserRoles",
                column: "RoleId");

            migrationBuilder.CreateIndex(
                name: "EmailIndex",
                table: "AspNetUsers",
                column: "NormalizedEmail");

            migrationBuilder.CreateIndex(
                name: "UserNameIndex",
                table: "AspNetUsers",
                column: "NormalizedUserName",
                unique: true,
                filter: "[NormalizedUserName] IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "IX_ExamInfos_NoticeId",
                table: "ExamInfos",
                column: "NoticeId");

            migrationBuilder.CreateIndex(
                name: "IX_ExamInfos_TokenId",
                table: "ExamInfos",
                column: "TokenId");

            migrationBuilder.CreateIndex(
                name: "IX_Notices_AdmissionClas",
                table: "Notices",
                column: "AdmissionClas");

            migrationBuilder.CreateIndex(
                name: "IX_Notices_SchoolId",
                table: "Notices",
                column: "SchoolId");

            migrationBuilder.CreateIndex(
                name: "IX_Payments_ApplyID",
                table: "Payments",
                column: "ApplyID");

            migrationBuilder.CreateIndex(
                name: "IX_Results_ExamInfoId",
                table: "Results",
                column: "ExamInfoId");

            migrationBuilder.CreateIndex(
                name: "IX_Results_TokenNumber",
                table: "Results",
                column: "TokenNumber");

            migrationBuilder.CreateIndex(
                name: "IX_SchoolInfos_AddressInfo",
                table: "SchoolInfos",
                column: "AddressInfo");

            migrationBuilder.CreateIndex(
                name: "IX_SchoolInfos_EduSystem",
                table: "SchoolInfos",
                column: "EduSystem");

            migrationBuilder.CreateIndex(
                name: "IX_StudentInfos_PreviousSchoolInfoId",
                table: "StudentInfos",
                column: "PreviousSchoolInfoId");

            migrationBuilder.CreateIndex(
                name: "IX_StudentInfos_StudentAddress",
                table: "StudentInfos",
                column: "StudentAddress");

            migrationBuilder.CreateIndex(
                name: "IX_Tokens_SchoolId",
                table: "Tokens",
                column: "SchoolId");

            migrationBuilder.CreateIndex(
                name: "IX_Tokens_StudentId",
                table: "Tokens",
                column: "StudentId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "AdmitCards");

            migrationBuilder.DropTable(
                name: "AspNetRoleClaims");

            migrationBuilder.DropTable(
                name: "AspNetUserClaims");

            migrationBuilder.DropTable(
                name: "AspNetUserLogins");

            migrationBuilder.DropTable(
                name: "AspNetUserRoles");

            migrationBuilder.DropTable(
                name: "AspNetUserTokens");

            migrationBuilder.DropTable(
                name: "Payments");

            migrationBuilder.DropTable(
                name: "Results");

            migrationBuilder.DropTable(
                name: "AspNetRoles");

            migrationBuilder.DropTable(
                name: "AspNetUsers");

            migrationBuilder.DropTable(
                name: "ApplyForms");

            migrationBuilder.DropTable(
                name: "ExamInfos");

            migrationBuilder.DropTable(
                name: "StudentSubjectGPAs");

            migrationBuilder.DropTable(
                name: "Notices");

            migrationBuilder.DropTable(
                name: "Tokens");

            migrationBuilder.DropTable(
                name: "AdmissionClasses");

            migrationBuilder.DropTable(
                name: "StudentInfos");

            migrationBuilder.DropTable(
                name: "SchoolInfos");

            migrationBuilder.DropTable(
                name: "PreviousSchoolInfos");

            migrationBuilder.DropTable(
                name: "Addresses");

            migrationBuilder.DropTable(
                name: "EducationSystems");
        }
    }
}
