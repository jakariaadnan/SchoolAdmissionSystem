﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace AdmissionSystemAPI.Migrations
{
    public partial class tokenIdRandom : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ApplyForms_Tokens_TokenId",
                table: "ApplyForms");

            migrationBuilder.DropForeignKey(
                name: "FK_ExamInfos_Tokens_TokenId",
                table: "ExamInfos");

            migrationBuilder.DropForeignKey(
                name: "FK_Results_Tokens_TokenNumber",
                table: "Results");

            migrationBuilder.DropTable(
                name: "Tokens");

            migrationBuilder.DropIndex(
                name: "IX_Results_TokenNumber",
                table: "Results");

            migrationBuilder.DropIndex(
                name: "IX_ExamInfos_TokenId",
                table: "ExamInfos");

            migrationBuilder.DropIndex(
                name: "IX_ApplyForms_TokenId",
                table: "ApplyForms");

            migrationBuilder.DropColumn(
                name: "TokenId",
                table: "ExamInfos");

            migrationBuilder.AlterColumn<string>(
                name: "TokenNumber",
                table: "Results",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AddColumn<string>(
                name: "TokenNumber",
                table: "ExamInfos",
                nullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "TokenId",
                table: "ApplyForms",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "TokenNumber",
                table: "ExamInfos");

            migrationBuilder.AlterColumn<int>(
                name: "TokenNumber",
                table: "Results",
                type: "int",
                nullable: false,
                oldClrType: typeof(string),
                oldNullable: true);

            migrationBuilder.AddColumn<int>(
                name: "TokenId",
                table: "ExamInfos",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AlterColumn<int>(
                name: "TokenId",
                table: "ApplyForms",
                type: "int",
                nullable: false,
                oldClrType: typeof(string),
                oldNullable: true);

            migrationBuilder.CreateTable(
                name: "Tokens",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    SchoolId = table.Column<int>(type: "int", nullable: false),
                    StudentId = table.Column<int>(type: "int", nullable: false),
                    TokenNum = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tokens", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Tokens_SchoolInfos_SchoolId",
                        column: x => x.SchoolId,
                        principalTable: "SchoolInfos",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Tokens_StudentInfos_StudentId",
                        column: x => x.StudentId,
                        principalTable: "StudentInfos",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Results_TokenNumber",
                table: "Results",
                column: "TokenNumber");

            migrationBuilder.CreateIndex(
                name: "IX_ExamInfos_TokenId",
                table: "ExamInfos",
                column: "TokenId");

            migrationBuilder.CreateIndex(
                name: "IX_ApplyForms_TokenId",
                table: "ApplyForms",
                column: "TokenId");

            migrationBuilder.CreateIndex(
                name: "IX_Tokens_SchoolId",
                table: "Tokens",
                column: "SchoolId");

            migrationBuilder.CreateIndex(
                name: "IX_Tokens_StudentId",
                table: "Tokens",
                column: "StudentId");

            migrationBuilder.AddForeignKey(
                name: "FK_ApplyForms_Tokens_TokenId",
                table: "ApplyForms",
                column: "TokenId",
                principalTable: "Tokens",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_ExamInfos_Tokens_TokenId",
                table: "ExamInfos",
                column: "TokenId",
                principalTable: "Tokens",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Results_Tokens_TokenNumber",
                table: "Results",
                column: "TokenNumber",
                principalTable: "Tokens",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
